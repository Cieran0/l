// SPDX-License-Identifier: ISC
/*
 * Copyright (C) 2021 Lorenzo Bianconi <lorenzo@kernel.org>
 */

#include <linux/module.h>

#ifndef __CHECKER__
#define CREATE_TRACE_POINTS
#include "mt7921_trace.h"

#endif
